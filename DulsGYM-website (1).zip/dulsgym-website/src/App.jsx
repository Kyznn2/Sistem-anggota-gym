import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import ProtectedRoute from '@/components/ProtectedRoute';
import GymLayout from '@/components/gym/GymLayout';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import Dashboard from '@/pages/Dashboard';
import Packages from '@/pages/Packages';
import PackageDetail from '@/pages/PackageDetail';
import Members from '@/pages/Members';
import Membership from '@/pages/Membership';
import Payments from '@/pages/Payments';
import PaymentHistory from '@/pages/PaymentHistory';
import Reports from '@/pages/Reports';
import DesignExport from '@/pages/DesignExport';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Keep account entry and recovery routes reachable.
      if (!['/login', '/register', '/forgot-password', '/reset-password'].includes(window.location.pathname)) {
        navigateToLogin();
        return null;
      }
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route element={<GymLayout />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/paket" element={<Packages />} />
          <Route path="/paket/:id" element={<PackageDetail />} />
          <Route path="/membership" element={<Membership />} />
          <Route path="/riwayat" element={<PaymentHistory />} />
          <Route path="/admin/anggota" element={<Members />} />
          <Route path="/admin/pembayaran" element={<Payments />} />
          <Route path="/admin/laporan" element={<Reports />} />
          <Route path="/design-export" element={<DesignExport />} />
        </Route>
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App