import { useState } from 'react';
import { useInfiniteQuery } from '@tanstack/react-query';
import { Plus } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import PageHeading from '@/components/gym/PageHeading';
import PackageCard from '@/components/gym/PackageCard';
import PackageEditor from '@/components/gym/PackageEditor';
import PurchaseDialog from '@/components/gym/PurchaseDialog';
import useGym from '@/components/gym/useGym';
import Feedback from '@/components/gym/Feedback';
export default function Packages(){const {admin,refresh}=useGym(),[editor,setEditor]=useState(null),[buy,setBuy]=useState(null);const q=useInfiniteQuery({queryKey:['gym','packages',admin],initialPageParam:undefined,queryFn:({pageParam})=>base44.entities.GymPackage.filter(admin?{}:{active:true},{sort:'price',limit:12,cursor:pageParam}),getNextPageParam:p=>p.has_more?p.next_cursor:undefined});const packs=q.data?.pages.flatMap(p=>p.items)||[];return <><PageHeading eyebrow="MEMBERSHIP / PACKAGES" title="Paket membership" description={admin?'Paket yang tepat untuk setiap perjalanan anggota.':'Investasi untuk dirimu. Pilih kuota yang sesuai dengan ritmemu.'}>{admin && <Button onClick={()=>setEditor({})} className="text-xs"><Plus className="size-4 mr-2"/>Tambah paket</Button>}</PageHeading><Feedback loading={q.isPending} error={q.error} empty={!q.isPending && !packs.length}/><div className="grid md:grid-cols-2 xl:grid-cols-3 gap-5">{packs.map(pack=><PackageCard key={pack.id} pack={pack} admin={admin} onEdit={setEditor} onBuy={setBuy}/>)}</div>{q.hasNextPage && <Button variant="outline" className="mt-5" disabled={q.isFetchingNextPage} onClick={()=>q.fetchNextPage()}>Muat paket lainnya</Button>}<p className="text-xs text-muted-foreground mt-7 text-center">Semua paket berdasarkan kunjungan. Sisa kuota tetap tersimpan saat perpanjangan.</p>{editor && <PackageEditor pack={editor.id?editor:null} onClose={()=>setEditor(null)} onSaved={refresh}/>} {buy && <PurchaseDialog pack={buy} onClose={()=>setBuy(null)}/>}</>;}