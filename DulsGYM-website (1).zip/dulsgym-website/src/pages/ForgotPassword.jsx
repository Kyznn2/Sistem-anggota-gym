import React,{useState} from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Mail } from 'lucide-react';
import AuthLayout from '@/components/AuthLayout';
export default function ForgotPassword(){const [email,setEmail]=useState(''),[loading,setLoading]=useState(false),[sent,setSent]=useState(false);async function handleSubmit(e){e.preventDefault();setLoading(true);try{await base44.auth.resetPasswordRequest(email);}catch{}finally{setLoading(false);setSent(true);}}return <AuthLayout icon={Mail} title="Lupa kata sandi?" subtitle="Kami akan mengirim tautan untuk mengatur ulang kata sandi." footer={<Link to="/login" className="text-primary">Kembali ke login</Link>}>{sent?<p className="text-sm text-center">Jika akun dengan email tersebut terdaftar, tautan pengaturan ulang kata sandi akan dikirim.</p>:<form onSubmit={handleSubmit} className="space-y-4"><div className="space-y-2"><Label htmlFor="email">Alamat email</Label><Input id="email" type="email" autoComplete="email" required placeholder="nama@email.com" value={email} onChange={e=>setEmail(e.target.value)} className="h-12"/></div><Button disabled={loading} type="submit" className="w-full h-12">{loading?'Mengirim...':'Kirim tautan reset'}</Button></form>}</AuthLayout>;}