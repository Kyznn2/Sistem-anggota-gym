import PaymentList from '@/components/gym/PaymentList';
export default function PaymentHistory(){return <PaymentList/>;}