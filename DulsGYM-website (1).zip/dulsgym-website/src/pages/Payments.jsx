import PaymentList from '@/components/gym/PaymentList';
export default function Payments(){return <PaymentList management/>;}