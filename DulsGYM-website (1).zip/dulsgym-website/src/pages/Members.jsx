import MemberDirectory from '@/components/gym/MemberDirectory';
export default function Members(){return <MemberDirectory/>;}