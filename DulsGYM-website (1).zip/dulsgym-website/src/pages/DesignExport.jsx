import { Navigate } from 'react-router-dom';
import useGym from '@/components/gym/useGym';
import PageHeading from '@/components/gym/PageHeading';
import ExportFiles from '@/components/design/ExportFiles';
import PreviewFrame from '@/components/design/PreviewFrame';
import ScreenIndex from '@/components/design/ScreenIndex';
import svgUrl from '@/assets/figma/dulsgym-ui-kit.svg?url';

export default function DesignExport() {
  const { admin } = useGym();
  if (!admin) return <Navigate to="/" replace />;
  return (
    <>
      <PageHeading
        eyebrow="DESIGN / EXPORT"
        title="Ekspor desain"
        description="Unduh seluruh berkas website beserta aset desain yang siap diimpor ke Figma."
      />
      <ExportFiles svgUrl={svgUrl} />
      <PreviewFrame svgUrl={svgUrl} />
      <ScreenIndex />
    </>
  );
}