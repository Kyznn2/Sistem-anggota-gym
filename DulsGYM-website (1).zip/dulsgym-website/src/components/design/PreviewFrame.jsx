import { ArrowUpRight } from 'lucide-react';
import { Image } from '@/components/ui/image';

export default function PreviewFrame({ svgUrl }) {
  return (
    <section className="bg-card border border-border rounded-xl mt-6 p-5 md:p-6">
      <div className="flex flex-wrap justify-between items-start gap-3 mb-4">
        <div>
          <h2 className="text-sm font-semibold">Pratinjau papan</h2>
          <p className="text-xs text-muted-foreground mt-1">Semua layar dalam satu papan, urut sesuai canvas.</p>
        </div>
        <a href={svgUrl} target="_blank" rel="noreferrer" className="text-xs text-primary inline-flex items-center gap-1">
          Buka ukuran penuh <ArrowUpRight className="size-3" />
        </a>
      </div>
      <div className="rounded-lg border border-border bg-background overflow-auto max-h-[560px]">
        <Image src={svgUrl} alt="Papan UI/UX DulsGYM" fittingType="fill" className="w-[1500px] max-w-none h-auto" />
      </div>
    </section>
  );
}