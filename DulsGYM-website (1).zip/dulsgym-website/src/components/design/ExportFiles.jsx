import { Archive, Download, FileCode2, Palette } from 'lucide-react';
import { Button } from '@/components/ui/button';
import tokensUrl from '@/assets/figma/dulsgym-tokens.json?url';
import zipUrl from '@/assets/export/dulsgym-website.zip?url';

const FILES = [
  {
    icon: Archive,
    name: 'DulsGYM-website.zip',
    meta: '143 berkas · seluruh kode website: antarmuka, backend, konfigurasi, dokumentasi, dan aset desain',
    note: 'Setiap berkas tetap pada format aslinya (.jsx, .js, .ts, .jsonc, .css, .md, .svg). Ekstrak, lalu jalankan npm install dan npm run dev.',
    href: zipUrl,
    file: 'DulsGYM-website.zip'
  },
  {
    icon: FileCode2,
    name: 'DulsGYM-UI-Kit.svg',
    meta: '12 layar + design system · 4920 × 7251 px · teks & bentuk tetap bisa diedit',
    note: 'Impor ke Figma lewat File → Place image, atau tarik berkasnya ke canvas. Klik kanan → Ungroup untuk mengedit per komponen.',
    href: null,
    file: 'DulsGYM-UI-Kit.svg'
  },
  {
    icon: Palette,
    name: 'DulsGYM-tokens.json',
    meta: 'Warna, tipografi, radius, dan spasi',
    note: 'Impor dengan plugin Tokens Studio untuk menjadikannya variabel warna dan teks di Figma.',
    href: tokensUrl,
    file: 'DulsGYM-tokens.json'
  }
];

export default function ExportFiles({ svgUrl }) {
  return (
    <section className="bg-card border border-border rounded-xl p-5 md:p-6">
      <div className="flex justify-between items-start mb-5">
        <div>
          <h2 className="text-sm font-semibold">Berkas unduhan</h2>
          <p className="text-xs text-muted-foreground mt-1">Kode website dan aset desain, siap diunduh.</p>
        </div>
        <span className="text-[10px] bg-secondary rounded-md px-2 py-1 text-muted-foreground">FIGMA READY</span>
      </div>
      {FILES.map((f, i) => {
        const Icon = f.icon;
        const href = f.href || svgUrl;
        return (
          <div key={f.name} className={`flex flex-wrap items-start gap-4 py-4 ${i ? 'border-t border-border' : ''}`}>
            <div className="rounded-lg bg-secondary p-2.5">
              <Icon className="size-4 text-primary" />
            </div>
            <div className="flex-1 min-w-[220px]">
              <p className="text-sm font-semibold">{f.name}</p>
              <p className="text-xs text-muted-foreground mt-1">{f.meta}</p>
              <p className="text-[11px] text-muted-foreground leading-relaxed mt-2">{f.note}</p>
            </div>
            <Button asChild variant="outline" size="sm" className="text-xs">
              <a href={href} download={f.file}>
                <Download className="size-4 mr-2" />Unduh
              </a>
            </Button>
          </div>
        );
      })}
    </section>
  );
}