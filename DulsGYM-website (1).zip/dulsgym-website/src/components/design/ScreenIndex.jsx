const SCREENS = [
  ['Dashboard', '/', 'Admin', 'Statistik, hero, grafik pendapatan, akses cepat'],
  ['Login', '/login', 'Publik', 'Toggle anggota/admin, Google, form email'],
  ['Register', '/register', 'Publik', 'Google, email, sandi, konfirmasi'],
  ['ForgotPassword', '/forgot-password', 'Publik', 'Kirim tautan reset'],
  ['ResetPassword', '/reset-password', 'Publik', 'Sandi baru + konfirmasi'],
  ['Packages', '/paket', 'Admin & anggota', 'Kartu paket, lencana populer, kelola/beli'],
  ['PackageDetail', '/paket/:id', 'Anggota', 'Deskripsi, fasilitas, harga, CTA beli'],
  ['Membership', '/membership', 'Anggota', 'Kartu status, sisa kuota, alur membership'],
  ['Members', '/admin/anggota', 'Admin', 'Cari, filter status, tabel anggota, tindakan'],
  ['Payments', '/admin/pembayaran', 'Admin', 'Filter, tabel transaksi, verifikasi'],
  ['PaymentHistory', '/riwayat', 'Anggota', 'Filter, tabel transaksi anggota'],
  ['Reports', '/admin/laporan', 'Admin', 'Rentang tanggal, statistik, grafik, performa paket']
];

export default function ScreenIndex() {
  return (
    <section className="bg-card border border-border rounded-xl mt-6 p-5 md:p-6">
      <h2 className="text-sm font-semibold">Isi berkas · 12 layar</h2>
      <p className="text-xs text-muted-foreground mt-1 mb-5">Setiap layar adalah frame 1440px dengan sidebar, header, dan footer sesuai peran.</p>
      <div className="overflow-x-auto">
        <table className="w-full text-xs text-left whitespace-nowrap">
          <thead className="text-muted-foreground border-b border-border">
            <tr>
              {['Layar', 'Rute', 'Peran', 'Isi utama'].map((h) => (
                <th key={h} className="pb-3 font-normal">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {SCREENS.map(([name, route, role, content]) => (
              <tr key={name} className="border-b border-border last:border-0">
                <td className="py-3 pr-4 font-semibold">{name}</td>
                <td className="py-3 pr-4 text-muted-foreground">{route}</td>
                <td className="py-3 pr-4 text-muted-foreground">{role}</td>
                <td className="py-3 text-muted-foreground">{content}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}