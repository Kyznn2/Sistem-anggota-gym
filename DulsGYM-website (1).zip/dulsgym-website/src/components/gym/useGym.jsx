import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { action } from '@/components/gym/helpers';
export default function useGym() {
 const {user} = useAuth(), queryClient = useQueryClient();
 const member = useQuery({queryKey:['gym','me',user?.id],queryFn:()=>action('ensureMember'),enabled:!!user});
 return {user,member:member.data,loading:member.isPending,error:member.error,admin:user?.role === 'admin',refresh:()=>queryClient.invalidateQueries({queryKey:['gym']})};
}