/**
 * Ekspor UI/UX canvas DulsGYM menjadi berkas Figma-ready:
 *   src/assets/figma/dulsgym-ui-kit.svg   (12 layar + design system, layer vektor & teks)
 *   src/assets/figma/dulsgym-tokens.json  (token warna, tipografi, radius)
 *
 * Jalankan: node scripts/export-figma.mjs
 * Sumber kebenaran tata letak: src/pages/*, src/components/gym/*, src/components/AuthLayout.jsx
 */
import fs from 'node:fs';
import path from 'node:path';

/* ────────────────────────── TOKENS ────────────────────────── */
const C = {
  bg: '#0F1114',
  card: '#191B1F',
  fg: '#F3F5F6',
  primary: '#BFF04C',
  primaryFg: '#111318',
  secondary: '#262930',
  muted: '#21242B',
  mutedFg: '#979CA5',
  border: '#2B2F35',
  accent: '#2F3522',
  destructive: '#E75A5A',
  canvas: '#07080A'
};
const FONT = 'Inter, system-ui, -apple-system, sans-serif';
const W = 1440;
const SIDEBAR = 240;
const PAD = 36;
const CX = SIDEBAR + PAD;            // 276
const CW = W - SIDEBAR - PAD * 2;    // 1128
const FOOT = 56;

/* ────────────────────────── PRIMITIF ────────────────────────── */
const nm = (v) => Math.round(v * 10) / 10;
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const tw = (s, size = 14, weight = 400) => String(s).length * size * (weight >= 600 ? 0.56 : 0.52);

function rect(x, y, w, h, o = {}) {
  let a = `x="${nm(x)}" y="${nm(y)}" width="${nm(w)}" height="${nm(h)}"`;
  if (o.rx != null) a += ` rx="${nm(o.rx)}"`;
  a += ` fill="${o.fill || 'none'}"`;
  if (o.stroke) a += ` stroke="${o.stroke}" stroke-width="${o.sw || 1}"`;
  if (o.opacity != null) a += ` opacity="${o.opacity}"`;
  if (o.dash) a += ` stroke-dasharray="${o.dash}"`;
  return `<rect ${a}/>`;
}
const line = (x1, y1, x2, y2, o = {}) =>
  `<line x1="${nm(x1)}" y1="${nm(y1)}" x2="${nm(x2)}" y2="${nm(y2)}" stroke="${o.stroke || C.border}" stroke-width="${o.sw || 1}"${o.opacity != null ? ` opacity="${o.opacity}"` : ''}/>`;
const circle = (cx, cy, r, o = {}) =>
  `<circle cx="${nm(cx)}" cy="${nm(cy)}" r="${nm(r)}" fill="${o.fill || 'none'}"${o.stroke ? ` stroke="${o.stroke}" stroke-width="${o.sw || 1}"` : ''}/>`;

function txt(x, y, s, o = {}) {
  let a = `x="${nm(x)}" y="${nm(y)}" font-family="${o.font || FONT}" font-size="${o.size || 14}" fill="${o.fill || C.fg}"`;
  if (o.weight) a += ` font-weight="${o.weight}"`;
  if (o.ls) a += ` letter-spacing="${o.ls}"`;
  if (o.opacity != null) a += ` opacity="${o.opacity}"`;
  if (o.anchor) a += ` text-anchor="${o.anchor}"`;
  return `<text ${a}>${esc(s)}</text>`;
}
const richTxt = (x, y, parts, o = {}) => {
  let a = `x="${nm(x)}" y="${nm(y)}" font-family="${o.font || FONT}" font-size="${o.size || 14}" fill="${o.fill || C.fg}"`;
  if (o.weight) a += ` font-weight="${o.weight}"`;
  if (o.anchor) a += ` text-anchor="${o.anchor}"`;
  const inner = parts.map((p) => `<tspan${p.fill ? ` fill="${p.fill}"` : ''}${p.weight ? ` font-weight="${p.weight}"` : ''}>${esc(p.s)}</tspan>`).join('');
  return `<text ${a}>${inner}</text>`;
};
function para(x, yTop, lines, o = {}) {
  const size = o.size || 13, lh = o.lh || Math.round(size * 1.55);
  return lines.map((l, i) => txt(x, yTop + size + i * lh, l, { size, fill: o.fill || C.mutedFg, weight: o.weight, anchor: o.anchor, ls: o.ls })).join('');
}

/* ikon: baca definisi asli lucide agar bentuknya identik dengan aplikasi */
const iconDir = path.resolve('node_modules/lucide-react/dist/esm/icons');
const iconCache = new Map();
const ICON_ALIAS = { 'bar-chart-3': 'chart-column' };
function iconEls(name) {
  name = ICON_ALIAS[name] || name;
  if (iconCache.has(name)) return iconCache.get(name);
  let els = null;
  const file = path.join(iconDir, `${name}.js`);
  if (fs.existsSync(file)) {
    const src = fs.readFileSync(file, 'utf8');
    els = [];
    const re = /\[\s*"(path|circle|rect|line|polyline|polygon|ellipse)"\s*,\s*\{([\s\S]*?)\}\s*\]/g;
    let m;
    while ((m = re.exec(src))) {
      const attrs = {};
      const are = /([a-zA-Z-]+):\s*"([^"]*)"/g;
      let a;
      while ((a = are.exec(m[2]))) if (a[1] !== 'key') attrs[a[1]] = a[2];
      els.push({ tag: m[1], attrs });
    }
  }
  if (!els || !els.length) console.warn('ikon tidak ditemukan:', name);
  iconCache.set(name, els || []);
  return els || [];
}
function ico(name, x, y, size, color, sw = 2) {
  const body = iconEls(name)
    .map((e) => `<${e.tag} ${Object.entries(e.attrs).map(([k, v]) => `${k}="${esc(v)}"`).join(' ')}/>`)
    .join('');
  const k = nm(size / 24);
  return `<g transform="translate(${nm(x)},${nm(y)}) scale(${k})" fill="none" stroke="${color}" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round">${body}</g>`;
}

const defs = [];
let clipSeq = 0;
function clipGroup(x, y, w, h, rx, content) {
  const id = `clip-${++clipSeq}`;
  defs.push(`<clipPath id="${id}"><rect x="${nm(x)}" y="${nm(y)}" width="${nm(w)}" height="${nm(h)}" rx="${nm(rx)}"/></clipPath>`);
  return `<g clip-path="url(#${id})">${content}</g>`;
}

/* ────────────────────────── DATA CONTOH (dari database) ────────────────────────── */
const PACKS = [
  {
    name: 'Starter', price: 150000, visits: 5, featured: false,
    desc: 'Langkah pertama menuju rutinitas yang lebih sehat. Fleksibel, tanpa batas masa aktif.',
    features: ['Akses seluruh area gym', 'Peralatan cardio & strength', 'Loker saat latihan']
  },
  {
    name: 'Momentum', price: 350000, visits: 15, featured: true,
    desc: 'Bangun konsistensi dan temukan ritme latihanmu. Pilihan ideal untuk progres nyata.',
    features: ['Akses seluruh area gym', 'Peralatan cardio & strength', 'Loker saat latihan', 'Orientasi alat bersama staf']
  },
  {
    name: 'Performance', price: 600000, visits: 30, featured: false,
    desc: 'Untuk kamu yang siap melangkah lebih jauh. Lebih banyak latihan, lebih banyak potensi.',
    features: ['Akses seluruh area gym', 'Peralatan cardio & strength', 'Loker saat latihan', 'Orientasi alat bersama staf']
  }
];
const MEMBERS = [
  { name: 'Czynn', email: 'akbarmaur02@gmail.com', phone: '', status: 'inactive', remaining: 0, visits: 0 },
  { name: 'millati izzatillah', email: 'millatiizzatillah@gmail.com', phone: '', status: 'active', remaining: 10, visits: 0 },
  { name: 'Coim Malboro359', email: 'coimmalboro359@gmail.com', phone: '', status: 'active', remaining: 12, visits: 3 },
  { name: 'akbarmaur00', email: 'akbarmaur00@gmail.com', phone: '', status: 'active', remaining: 27, visits: 3 },
  { name: 'nirwan', email: 'roleplayer2254@gmail.com', phone: '088265489578', status: 'active', remaining: 33, visits: 2 },
  { name: '1596 _ abdul rochim', email: 'abdlrochim2002@gmail.com', phone: '', status: 'active', remaining: 28, visits: 2 }
];
const PAYS = [
  { name: 'millati izzatillah', pkg: 'Starter', amount: 150000, visits: 5, method: 'gym', status: 'paid', date: '16 Okt 2026', ref: 'A1B2C3D4' },
  { name: 'Coim Malboro359', pkg: 'Momentum', amount: 350000, visits: 15, method: 'gym', status: 'paid', date: '16 Okt 2026', ref: 'E5F6A7B8' },
  { name: 'akbarmaur00', pkg: 'Performance', amount: 600000, visits: 30, method: 'gym', status: 'paid', date: '06 Okt 2026', ref: 'C9D0E1F2' },
  { name: 'nirwan', pkg: 'Performance', amount: 600000, visits: 30, method: 'online', status: 'paid', date: '06 Okt 2026', ref: '3A4B5C6D' },
  { name: '1596 _ abdul rochim', pkg: 'Performance', amount: 600000, visits: 30, method: 'gym', status: 'paid', date: '06 Okt 2026', ref: '7E8F9A0B' },
  { name: 'Czynn', pkg: 'Starter', amount: 150000, visits: 5, method: 'gym', status: 'pending', date: '12 Nov 2026', ref: '1C2D3E4F' }
];
const money = (v) => 'Rp' + new Intl.NumberFormat('id-ID').format(v || 0);

/* ────────────────────────── KOMPONEN UI ────────────────────────── */
const STATUS = {
  paid: { label: 'Lunas', tone: 'good' },
  active: { label: 'Aktif', tone: 'good' },
  pending: { label: 'Menunggu verifikasi', tone: 'neutral' },
  rejected: { label: 'Ditolak', tone: 'muted' },
  expired: { label: 'Kedaluwarsa', tone: 'muted' },
  inactive: { label: 'Belum aktif', tone: 'muted' },
  suspended: { label: 'Nonaktif', tone: 'muted' }
};
function statusBadge(x, y, value) {
  const s = STATUS[value] || { label: value, tone: 'muted' };
  const size = 12, padX = 10, h = 24;
  const w = Math.round(tw(s.label, size) + padX * 2 + 13);
  const bg = s.tone === 'good' ? C.primary : s.tone === 'neutral' ? C.secondary : C.muted;
  const fg = s.tone === 'good' ? C.primary : s.tone === 'neutral' ? C.fg : C.mutedFg;
  const svg =
    rect(x, y, w, h, { fill: bg, rx: 12, opacity: s.tone === 'good' ? 0.14 : 1 }) +
    circle(x + padX + 3, y + h / 2, 3, { fill: fg }) +
    txt(x + padX + 12, y + h / 2 + 4, s.label, { size, fill: fg, weight: 500 });
  return { svg, w };
}

function button(x, y, w, h, label, o = {}) {
  const variant = o.variant || 'primary';
  const fill = variant === 'primary' ? C.primary : 'none';
  const stroke = variant === 'outline' ? C.border : null;
  const fg = variant === 'primary' ? C.primaryFg : variant === 'ghost' ? C.mutedFg : C.fg;
  let s = rect(x, y, w, h, { fill, stroke, rx: o.rx != null ? o.rx : 8 });
  const size = o.size || 13;
  const gap = o.icon ? 8 : 0;
  const iconSize = o.iconSize || 16;
  const contentW = (o.icon ? iconSize + gap : 0) + tw(label, size, 600) + (o.trailing ? iconSize + gap : 0);
  let cx = o.align === 'left' ? x + 16 : x + (w - contentW) / 2;
  if (o.icon) {
    s += ico(o.icon, cx, y + (h - iconSize) / 2, iconSize, o.iconColor || fg);
    cx += iconSize + gap;
  }
  s += txt(cx, y + h / 2 + size * 0.36, label, { size, weight: o.weight || 600, fill: fg });
  if (o.trailing) s += ico(o.trailing, x + w - 16 - iconSize, y + (h - iconSize) / 2, iconSize, fg);
  return s;
}

function field(x, y, w, o = {}) {
  const h = o.h || 44;
  let s = '';
  if (o.label) s += txt(x, y + 12, o.label, { size: 14, weight: 500 });
  const iy = o.label ? y + 20 : y;
  s += rect(x, iy, w, h, { fill: 'none', stroke: o.focus ? C.primary : C.border, rx: 8 });
  if (o.value) s += txt(x + 14, iy + h / 2 + 5, o.value, { size: 14 });
  else if (o.placeholder) s += txt(x + 14, iy + h / 2 + 5, o.placeholder, { size: 14, fill: C.mutedFg });
  return { svg: s, bottom: iy + h };
}

function cardBox(x, y, w, h, o = {}) {
  return rect(x, y, w, h, { fill: o.fill || C.card, stroke: o.stroke || C.border, rx: 12, sw: 1 });
}

function heading(y, o = {}) {
  let s = '';
  s += txt(CX, y + 11, o.eyebrow, { size: 10, weight: 600, fill: C.primary, ls: '0.2em' });
  s += richTxt(CX, y + 45, [{ s: o.title }, { s: '.', fill: C.primary }], { size: 30, weight: 700 });
  if (o.desc) s += txt(CX, y + 68, o.desc, { size: 14, fill: C.mutedFg });
  return s;
}

function statRow(y, items) {
  const gap = 16, cw = (CW - gap * 3) / 4;
  return items
    .map((it, i) => {
      const x = CX + i * (cw + gap);
      return (
        cardBox(x, y, cw, 128) +
        rect(x + cw - 52, y + 20, 32, 32, { fill: C.secondary, rx: 8 }) +
        ico(it.icon, x + cw - 44, y + 28, 16, C.primary) +
        txt(x + 20, y + 40, it.label, { size: 12, fill: C.mutedFg }) +
        txt(x + 20, y + 86, it.value, { size: 24, weight: 600 }) +
        txt(x + 20, y + 106, it.caption, { size: 11, fill: C.mutedFg })
      );
    })
    .join('');
}

function authGoogle(x, y, w) {
  return (
    rect(x, y, w, 48, { fill: 'none', stroke: C.border, rx: 8 }) +
    `<g transform="translate(${nm(x + (w - 18) / 2 - 78)},${nm(y + 15)}) scale(0.75)"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></g>` +
    txt(x + (w - 18) / 2 - 78 + 26, y + 30, 'Lanjutkan dengan Google', { size: 14 })
  );
}

/* ────────────────────────── SHELL APLIKASI ────────────────────────── */
const MENU_MEMBER = [
  ['Dashboard', 'layout-dashboard'],
  ['Paket membership', 'layers'],
  ['Membership', 'activity'],
  ['Riwayat pembayaran', 'credit-card']
];
const MENU_ADMIN = [
  ['Dashboard', 'layout-dashboard'],
  ['Data anggota', 'users'],
  ['Paket membership', 'layers'],
  ['Pembayaran', 'credit-card'],
  ['Status membership', 'activity'],
  ['Laporan', 'bar-chart-3']
];

function sidebar(admin, active, h) {
  const items = admin ? MENU_ADMIN : MENU_MEMBER;
  let s = rect(0, 0, SIDEBAR, h, { fill: C.card }) + line(SIDEBAR, 0, SIDEBAR, h, { stroke: C.border });
  s += rect(20, 28, 32, 32, { fill: C.primary, rx: 8 });
  s += ico('dumbbell', 26, 34, 20, C.primaryFg);
  s += richTxt(62, 51, [{ s: 'DULS' }, { s: '.', fill: C.primary }], { size: 20, weight: 700 });
  s += txt(140, 51, 'GYM', { size: 11, fill: C.mutedFg, ls: '0.16em' });
  s += txt(21, 104, 'MENU UTAMA', { size: 10, weight: 500, fill: C.mutedFg, ls: '0.16em' });
  let ny = 118;
  items.forEach(([label, icon]) => {
    const on = label === active;
    if (on) s += rect(20, ny, SIDEBAR - 40, 44, { fill: C.primary, rx: 8 });
    s += ico(icon, 34, ny + 13, 18, on ? C.primaryFg : C.mutedFg, on ? 2.2 : 2);
    s += txt(64, ny + 27, label, { size: 14, weight: on ? 600 : 400, fill: on ? C.primaryFg : C.mutedFg });
    ny += 50;
  });
  const cardY = h - FOOT - 40 - 16 - 124;
  s += rect(20, cardY, SIDEBAR - 40, 124, { fill: 'none', stroke: C.border, rx: 12 });
  s += ico('shield-check', 36, cardY + 20, 20, C.primary);
  s += txt(36, cardY + 62, admin ? 'Ruang administrator' : 'Ruang anggota', { size: 14, weight: 600 });
  s += para(36, cardY + 68, admin ? ['Kelola gym, tumbuhkan', 'komunitas.'] : ['Langkah kecil. Hasil', 'yang besar.'], { size: 11, lh: 16, fill: C.mutedFg });
  s += ico('log-out', 36, h - 56, 16, C.mutedFg);
  s += txt(60, h - 44, 'Keluar', { size: 14, fill: C.mutedFg });
  return s;
}

function topHeader(admin, name, role) {
  let s = line(SIDEBAR, 80, W, 80, { stroke: C.border });
  s += circle(CX + 3, 40, 3, { fill: C.primary });
  s += txt(CX + 14, 45, admin ? 'ADMIN WORKSPACE' : 'MEMBER WORKSPACE', { size: 12, fill: C.mutedFg, ls: '0.02em' });
  s += txt(CX + 155, 45, '/', { size: 12, fill: C.mutedFg });
  s += txt(CX + 172, 45, 'DULS.GYM', { size: 12, fill: C.mutedFg });
  s += txt(1356, 37, name, { size: 13, weight: 600, anchor: 'end' });
  s += txt(1356, 54, role, { size: 11, fill: C.mutedFg, anchor: 'end' });
  s += circle(1386, 40, 18, { fill: C.accent });
  s += txt(1386, 45, name.slice(0, 2).toUpperCase(), { size: 13, weight: 700, fill: C.primary, anchor: 'middle' });
  return s;
}

const appFooter = (h) =>
  line(CX, h - FOOT, W - PAD, h - FOOT, { stroke: C.border }) +
  txt(CX, h - FOOT + 24, '© 2026 DULS.GYM', { size: 10, fill: C.mutedFg, ls: '0.06em' }) +
  txt(W - PAD, h - FOOT + 24, 'BUILT FOR YOUR NEXT LEVEL', { size: 10, fill: C.mutedFg, anchor: 'end', ls: '0.06em' });

const appFrame = (h, { admin = false, active = 'Dashboard', name = 'Nirwan', role = 'Administrator', body = '' }) =>
  rect(0, 0, W, h, { fill: C.bg }) + sidebar(admin, active, h) + topHeader(admin, name, role) + body + appFooter(h);

/* ────────────────────────── KOMPONEN KHAS HALAMAN ────────────────────────── */
function heroCard(y, h = 220, admin = true) {
  const w = CW;
  let inner = `<image href="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&amp;fit=crop&amp;w=1400&amp;q=85" x="${CX + w - 520}" y="${y}" width="520" height="${h}" preserveAspectRatio="xMidYMid slice" opacity="0.45"/>`;
  inner += rect(CX + w - 900, y, 900, h, { fill: C.bg, opacity: 0.9 });
  inner += rect(CX + w - 620, y, 620, h, { fill: C.bg, opacity: 0.55 });
  let s = cardBox(CX, y, w, h);
  s += clipGroup(CX, y, w, h, 12, inner);
  s += txt(CX + 36, y + 46, 'STRONGER TOGETHER', { size: 10, weight: 600, fill: C.primary, ls: '0.22em' });
  s += txt(CX + 36, y + 92, admin ? 'Gym yang hebat.' : 'Mulai lebih kuat.', { size: 34, weight: 700 });
  s += txt(CX + 36, y + 134, admin ? 'Komunitas yang kuat.' : 'Jadilah versi terbaikmu.', { size: 34, weight: 700, fill: C.primary });
  s += txt(CX + 36, y + 166, admin ? 'Satu tempat untuk mengelola setiap langkah anggota Anda.' : 'Pilih paket, tambah kuota, dan buat setiap kunjungan berarti.', { size: 13, fill: C.mutedFg });
  s += button(CX + 36, y + 182, 148, 34, admin ? 'Kelola anggota' : 'Jelajahi paket', { size: 12, trailing: 'arrow-up-right', iconSize: 14 });
  return s;
}

function chartCard(x, y, w, h, o = {}) {
  let s = cardBox(x, y, w, h);
  s += txt(x + 24, y + 32, o.title, { size: 14, weight: 600 });
  s += txt(x + 24, y + 52, o.sub, { size: 12, fill: C.mutedFg });
  s += rect(x + w - 24 - 42, y + 24, 42, 22, { fill: C.secondary, rx: 6 });
  s += txt(x + w - 24 - 21, y + 39, 'IDR', { size: 10, fill: C.mutedFg, anchor: 'middle' });
  const px = x + 52, py = y + 84, pw = w - 76, ph = h - 132;
  for (let i = 0; i <= 3; i++) {
    const gy = py + ph - (ph * i) / 3;
    s += line(px, gy, px + pw, gy, { stroke: C.border, dash: '3 4', opacity: i === 0 ? 1 : 0.6 });
    s += txt(x + 24, gy + 4, o.yTicks?.[i] || '', { size: 10, fill: C.mutedFg });
  }
  const bars = o.bars || [];
  const step = pw / bars.length;
  const bw = Math.min(40, step * 0.5);
  bars.forEach((b, i) => {
    const bh = Math.max(4, (b.v / o.max) * ph);
    const bx = px + step * i + (step - bw) / 2;
    s += rect(bx, py + ph - bh, bw, bh, { fill: C.primary, rx: 5 });
    s += txt(px + step * i + step / 2, py + ph + 20, b.label, { size: 10, fill: C.mutedFg, anchor: 'middle' });
  });
  return s;
}

function tableBlock(x, y, w, o) {
  const cols = o.cols, rows = o.rows, rowH = o.rowH || 52, headH = o.headH || 44;
  const totalH = headH + rows.length * rowH;
  let inner = rect(x, y, w, headH, { fill: C.secondary, opacity: 0.4 });
  inner += line(x, y + headH, x + w, y + headH, { stroke: C.border });
  let cxp = x;
  cols.forEach((c) => {
    inner += txt(c.align === 'right' ? cxp + c.width - 20 : cxp + 20, y + headH / 2 + 4, c.label, { size: 12, fill: C.mutedFg, anchor: c.align === 'right' ? 'end' : 'start' });
    cxp += c.width;
  });
  let ry = y + headH;
  rows.forEach((cells, ri) => {
    if (ri < rows.length - 1) inner += line(x, ry + rowH, x + w, ry + rowH, { stroke: C.border, opacity: 0.85 });
    let cxx = x;
    cells.forEach((cell, ci) => {
      const c = cols[ci];
      const tx = c.align === 'right' ? cxx + c.width - 20 : cxx + 20;
      inner += cellSvg(tx, ry, rowH, cell, c.align === 'right' ? 'end' : 'start');
      cxx += c.width;
    });
    ry += rowH;
  });
  const box = o.bare ? '' : cardBox(x, y, w, totalH);
  return { svg: box + clipGroup(x, y, w, totalH, 12, inner), h: totalH };
}

function cellSvg(x, y, rowH, cell, anchor) {
  if (cell == null) return '';
  if (typeof cell === 'string') return txt(x, y + rowH / 2 + 4, cell, { size: 12, anchor });
  if (cell.t === 'status') return statusBadge(anchor === 'end' ? x - statusBadge(0, 0, cell.v).w : x, y + rowH / 2 - 12, cell.v).svg;
  if (cell.t === 'member') {
    let s = circle(x + 18, y + rowH / 2, 18, { fill: C.secondary });
    s += txt(x + 18, y + rowH / 2 + 5, cell.name.slice(0, 2).toUpperCase(), { size: 12, weight: 600, fill: C.primary, anchor: 'middle' });
    s += txt(x + 48, y + rowH / 2 - 2, cell.name.slice(0, 26), { size: 12, weight: 600 });
    s += txt(x + 48, y + rowH / 2 + 14, cell.email, { size: 11, fill: C.mutedFg });
    return s;
  }
  if (cell.t === 'actions') {
    let s = '';
    const icons = cell.items;
    icons.forEach((ic, i) => {
      const ix = x - 20 - (icons.length - i) * 30 + 14;
      s += ico(ic.name, ix, y + rowH / 2 - 8, 16, ic.color || C.mutedFg);
    });
    return s;
  }
  if (cell.t === 'link') {
    return txt(x, y + rowH / 2 + 4, cell.v, { size: 12, fill: C.fg, anchor }) + ico('arrow-up-right', anchor === 'end' ? x - tw(cell.v, 12) - 16 : x + tw(cell.v, 12) + 6, y + rowH / 2 - 6, 12, C.mutedFg);
  }
  let s = txt(x, y + rowH / 2 + 4, cell.v, { size: 12, weight: cell.weight || 400, fill: cell.color || C.fg, anchor });
  if (cell.sub) s += txt(x, y + rowH / 2 + 20, cell.sub, { size: 10, fill: C.mutedFg, anchor });
  return s;
}

/* ────────────────────────── LAYAR ────────────────────────── */
function authScreen({ h, icon, title, subtitle, footer, cardH, body }) {
  const cw = 448, cx = (W - cw) / 2;
  const total = 142 + cardH + (footer ? 36 : 0);
  const y0 = Math.max(64, Math.round((h - total) / 2));
  let s = rect(0, 0, W, h, { fill: C.bg });
  s += rect(cx + cw / 2 - 28, y0, 56, 56, { fill: C.primary, rx: 16 });
  s += ico(icon, cx + cw / 2 - 14, y0 + 14, 28, C.primaryFg);
  s += `<text x="${cx + cw / 2}" y="${y0 + 90}" text-anchor="middle" font-family="${FONT}" font-size="30" font-weight="700" fill="${C.fg}">${esc(title)}</text>`;
  if (subtitle) s += txt(cx + cw / 2, y0 + 116, subtitle, { size: 14, fill: C.mutedFg, anchor: 'middle' });
  const cardY = y0 + 142;
  s += rect(cx, cardY, cw, cardH, { fill: C.card, stroke: C.border, rx: 16 });
  s += body(cx + 32, cardY + 32, cw - 64);
  if (footer) s += footer(cx + cw / 2, cardY + cardH + 36);
  return s;
}

const SCREENS = {
  /* 1 · DASHBOARD (admin) */
  Dashboard: () => {
    const h = 1319;
    let y = 116;
    let body = heading(y, { eyebrow: 'OVERVIEW / ADMIN', title: 'Dashboard admin', desc: 'Selamat datang kembali, Nirwan. Mari buat hari ini lebih produktif.' });
    body += rect(W - PAD - 150, y + 6, 150, 34, { fill: 'none', stroke: C.border, rx: 8 });
    body += txt(W - PAD - 75, y + 28, '12 November 2026', { size: 12, fill: C.mutedFg, anchor: 'middle' });
    y += 103;
    body += statRow(y, [
      { label: 'Total anggota', value: '6', caption: '5 membership aktif', icon: 'users' },
      { label: 'Total pendapatan', value: 'Rp1.700.000', caption: 'Dari pembayaran terverifikasi', icon: 'wallet' },
      { label: 'Menunggu verifikasi', value: '1', caption: 'Pembayaran yang perlu diperiksa', icon: 'clock-3' },
      { label: 'Kunjungan hari ini', value: '2', caption: 'Check-in tercatat hari ini', icon: 'activity' }
    ]);
    y += 156;
    body += heroCard(y, 220, true);
    y += 244;
    const leftW = 687;
    body += chartCard(CX, y, leftW, 300, {
      title: 'Pendapatan membership', sub: 'Pembayaran terverifikasi per bulan',
      yTicks: ['2jt', '1,3jt', '666rb', '0'], max: 2000000,
      bars: [{ label: '2026-08', v: 600000 }, { label: '2026-09', v: 950000 }, { label: '2026-10', v: 1700000 }]
    });
    const qx = CX + leftW + 24, qw = CW - leftW - 24;
    body += cardBox(qx, y, qw, 300);
    body += txt(qx + 24, y + 32, 'Akses cepat', { size: 14, weight: 600 });
    body += txt(qx + 24, y + 52, 'Semua yang Anda butuhkan, lebih dekat.', { size: 12, fill: C.mutedFg });
    [['Kelola anggota', 'Undang dan kelola komunitas', 'users'], ['Kelola paket', 'Atur harga dan kuota kunjungan', 'layers'], ['Verifikasi pembayaran', 'Aktifkan membership anggota', 'shield-check']].forEach((it, i) => {
      const ry = y + 74 + i * 72;
      body += line(qx, ry, qx + qw, ry, { stroke: C.border });
      body += rect(qx + 24, ry + 18, 32, 32, { fill: C.secondary, rx: 8 });
      body += ico(it[2], qx + 32, ry + 26, 16, C.primary);
      body += txt(qx + 68, ry + 32, it[0], { size: 12, weight: 500 });
      body += txt(qx + 68, ry + 48, it[1], { size: 10, fill: C.mutedFg });
      body += ico('arrow-up-right', qx + qw - 40, ry + 30, 16, C.mutedFg);
    });
    y += 324;
    body += cardBox(CX, y, CW, 304);
    body += txt(CX + 24, y + 32, 'Pembayaran terbaru', { size: 14, weight: 600 });
    body += txt(CX + 24, y + 52, 'Pantau transaksi membership Anda', { size: 12, fill: C.mutedFg });
    body += txt(CX + CW - 24, y + 36, 'Lihat semua ↗', { size: 12, fill: C.primary, anchor: 'end' });
    const t = tableBlock(CX + 1, y + 68, CW - 2, {
      headH: 36, rowH: 48, bare: true,
      cols: [{ label: 'Anggota', width: 400 }, { label: 'Paket', width: 340 }, { label: 'Nominal', width: 220 }, { label: 'Status', width: 167, align: 'right' }],
      rows: PAYS.slice(0, 4).map((p) => [p.name, { v: p.pkg, color: C.mutedFg }, money(p.amount), { t: 'status', v: p.status }])
    });
    body += t.svg;
    return appFrame(h, { admin: true, active: 'Dashboard', name: 'Nirwan', role: 'Administrator', body });
  },

  /* 2 · LOGIN */
  Login: () => {
    const h = 918;
    return authScreen({
      h, icon: 'log-in', title: 'Selamat datang kembali', subtitle: 'Perjalanan lebih kuat dimulai di sini.',
      cardH: 524,
      footer: (x, y) => richTxt(x, y, [{ s: 'Belum memiliki akun? ', fill: C.mutedFg }, { s: 'Daftar anggota', fill: C.primary, weight: 500 }], { size: 14, anchor: 'middle' }),
      body: (x, y, w) => {
        let s = '';
        s += rect(x, y, w, 44, { fill: C.secondary, rx: 8 });
        s += rect(x + 4, y + 4, (w - 8) / 2, 36, { fill: C.primary, rx: 6 });
        s += txt(x + 4 + (w - 8) / 4, y + 27, 'Anggota', { size: 13, weight: 600, fill: C.primaryFg, anchor: 'middle' });
        s += txt(x + 4 + (w - 8) * 0.75, y + 27, 'Admin', { size: 13, fill: C.mutedFg, anchor: 'middle' });
        s += authGoogle(x, y + 68, w);
        s += txt(x + w / 2, y + 142, 'atau masuk dengan email', { size: 12, fill: C.mutedFg, anchor: 'middle' });
        let f = field(x, y + 168, w, { label: 'Email', h: 48, placeholder: 'nama@email.com' });
        s += f.svg;
        s += txt(x, y + 250, 'Kata sandi', { size: 14, weight: 500 });
        s += txt(x + w, y + 250, 'Lupa kata sandi?', { size: 12, fill: C.primary, anchor: 'end' });
        s += rect(x, y + 262, w, 48, { fill: 'none', stroke: C.border, rx: 8 });
        s += txt(x + 14, y + 262 + 29, 'Masukkan kata sandi', { size: 14, fill: C.mutedFg });
        s += button(x, y + 326, w, 48, 'Masuk dashboard anggota', { size: 14 });
        s += para(x + w / 2, y + 396, ['Akses dashboard ditentukan oleh peran akun,', 'bukan pilihan tombol login.'], { size: 11, fill: C.mutedFg, anchor: 'middle', lh: 15 });
        return s;
      }
    });
  },

  /* 3 · REGISTER */
  Register: () => {
    const h = 918;
    return authScreen({
      h, icon: 'user-plus', title: 'Daftar anggota', subtitle: 'Bergabung dengan komunitas Pulse Gym.',
      cardH: 470,
      footer: (x, y) => richTxt(x, y, [{ s: 'Sudah memiliki akun? ', fill: C.mutedFg }, { s: 'Masuk', fill: C.primary }], { size: 14, anchor: 'middle' }),
      body: (x, y, w) => {
        let s = authGoogle(x, y, w);
        s += txt(x + w / 2, y + 76, 'atau daftar dengan email', { size: 12, fill: C.mutedFg, anchor: 'middle' });
        s += field(x, y + 100, w, { label: 'Email', h: 48, placeholder: 'nama@email.com' }).svg;
        s += field(x, y + 182, w, { label: 'Kata sandi', h: 48, placeholder: 'Minimal 8 karakter' }).svg;
        s += field(x, y + 264, w, { label: 'Konfirmasi kata sandi', h: 48, placeholder: 'Ulangi kata sandi' }).svg;
        s += button(x, y + 344, w, 48, 'Daftar anggota', { size: 14 });
        return s;
      }
    });
  },

  /* 4 · FORGOT PASSWORD */
  ForgotPassword: () => {
    const h = 918;
    return authScreen({
      h, icon: 'mail', title: 'Lupa kata sandi?', subtitle: 'Kami akan mengirim tautan untuk mengatur ulang kata sandi.',
      cardH: 216,
      footer: (x, y) => txt(x, y, 'Kembali ke login', { size: 14, fill: C.primary, anchor: 'middle' }),
      body: (x, y, w) => {
        let s = field(x, y, w, { label: 'Alamat email', h: 48, placeholder: 'nama@email.com' }).svg;
        s += button(x, y + 88, w, 48, 'Kirim tautan reset', { size: 14 });
        return s;
      }
    });
  },

  /* 5 · RESET PASSWORD */
  ResetPassword: () => {
    const h = 918;
    return authScreen({
      h, icon: 'lock', title: 'Kata sandi baru', subtitle: 'Masukkan kata sandi baru untuk akun Anda.',
      cardH: 298,
      body: (x, y, w) => {
        let s = field(x, y, w, { label: 'Kata sandi baru', h: 48 }).svg;
        s += field(x, y + 82, w, { label: 'Konfirmasi kata sandi', h: 48 }).svg;
        s += button(x, y + 172, w, 48, 'Simpan kata sandi', { size: 14 });
        return s;
      }
    });
  },

  /* 6 · PAKET MEMBERSHIP */
  Packages: () => {
    const h = 1336;
    let y = 116;
    let body = heading(y, { eyebrow: 'MEMBERSHIP / PACKAGES', title: 'Paket membership', desc: 'Paket yang tepat untuk setiap perjalanan anggota.' });
    body += button(W - PAD - 132, y + 10, 132, 34, 'Tambah paket', { icon: 'plus', size: 12 });
    y += 103;
    const gap = 20, cw = (CW - gap * 2) / 3, ch = 452;
    PACKS.forEach((p, i) => {
      const x = CX + i * (cw + gap);
      body += cardBox(x, y, cw, ch, { fill: p.featured ? C.accent : C.card, stroke: p.featured ? C.primary : C.border });
      body += txt(x + 24, y + 34, `${p.visits} KUNJUNGAN`, { size: 11, fill: C.mutedFg, ls: '0.14em' });
      if (p.featured) {
        const bx = x + cw - 24 - 78;
        body += rect(bx, y + 20, 78, 22, { fill: C.primary, rx: 11 });
        body += ico('zap', bx + 8, y + 26, 12, C.primaryFg);
        body += txt(bx + 24, y + 35, 'POPULER', { size: 9, weight: 700, fill: C.primaryFg, ls: '0.04em' });
      }
      body += txt(x + 24, y + 68, p.name, { size: 20, weight: 700 });
      body += para(x + 24, y + 80, p.desc.match(/.{1,42}(\s|$)/g).map((s) => s.trim()), { size: 12, fill: C.mutedFg, lh: 18 });
      body += txt(x + 24, y + 168, money(p.price), { size: 28, weight: 600 });
      body += txt(x + 24, y + 190, 'Sekali bayar · Tanpa batas masa aktif', { size: 11, fill: C.mutedFg });
      body += line(x + 24, y + 206, x + cw - 24, y + 206, { stroke: C.border });
      p.features.forEach((f, fi) => {
        const fy = y + 226 + fi * 26;
        body += ico('check', x + 24, fy, 14, C.primary);
        body += txt(x + 46, fy + 12, f, { size: 12 });
      });
      body += button(x + 24, y + ch - 88, cw - 48, 38, 'Kelola paket', { icon: 'pencil', size: 12, variant: p.featured ? 'primary' : 'outline', trailing: 'arrow-up-right' });
      body += txt(x + cw / 2, y + ch - 32, 'Lihat detail paket', { size: 12, fill: C.mutedFg, anchor: 'middle' });
    });
    y += ch + 28;
    body += txt(W / 2 + 60, y, 'Semua paket berdasarkan kunjungan. Sisa kuota tetap tersimpan saat perpanjangan.', { size: 12, fill: C.mutedFg, anchor: 'middle' });
    return appFrame(h, { admin: true, active: 'Paket membership', name: 'Nirwan', role: 'Administrator', body });
  },

  /* 7 · DETAIL PAKET */
  PackageDetail: () => {
    const h = 900;
    const p = PACKS[0];
    let body = ico('arrow-left', CX, 118, 14, C.mutedFg) + txt(CX + 22, 129, 'Kembali ke paket', { size: 12, fill: C.mutedFg });
    const y = 152;
    body += heading(y, { eyebrow: 'MEMBERSHIP / DETAIL', title: p.name, desc: 'Paket membership berbasis kunjungan' });
    const cy = y + 103;
    const lw = 665, rw = CW - lw - 24;
    body += cardBox(CX, cy, lw, 420);
    body += ico('activity', CX + 28, cy + 28, 32, C.primary);
    body += txt(CX + 28, cy + 96, 'Tentang paket', { size: 18, weight: 600 });
    body += para(CX + 28, cy + 110, p.desc.match(/.{1,72}(\s|$)/g).map((s) => s.trim()), { size: 13, fill: C.mutedFg, lh: 21 });
    body += txt(CX + 28, cy + 214, 'Fasilitas yang termasuk', { size: 14, weight: 600 });
    p.features.forEach((f, i) => {
      const fy = cy + 238 + i * 34;
      body += ico('check', CX + 28, fy, 16, C.primary);
      body += txt(CX + 54, fy + 13, f, { size: 13 });
    });
    const rx = CX + lw + 24;
    body += cardBox(rx, cy, rw, 320, { fill: C.accent, stroke: C.primary });
    body += txt(rx + 28, cy + 40, 'Harga paket', { size: 13, fill: C.mutedFg });
    body += txt(rx + 28, cy + 78, money(p.price), { size: 30, weight: 700 });
    body += txt(rx + 28, cy + 110, `${p.visits} kunjungan gym`, { size: 13, weight: 500, fill: C.primary });
    body += para(rx + 28, cy + 126, ['Tanpa batas masa aktif. Setiap', 'check-in mengurangi satu kuota', 'kunjungan. Pembelian ulang menambah', 'sisa kuota setelah terverifikasi.'], { size: 11, fill: C.mutedFg, lh: 17 });
    body += button(rx + 28, cy + 250, rw - 56, 44, 'Beli / perpanjang paket', { size: 13 });
    return appFrame(h, { admin: false, active: 'Paket membership', name: 'millati izzatillah', role: 'Anggota', body });
  },

  /* 8 · MEMBERSHIP (anggota) */
  Membership: () => {
    const h = 918;
    let y = 116;
    let body = heading(y, { eyebrow: 'MY MEMBERSHIP', title: 'Membership saya', desc: 'Pantau status dan sisa kuota latihanmu.' });
    y += 103;
    const lw = 665, rw = CW - lw - 24;
    body += cardBox(CX, y, lw, 400, { stroke: C.primary });
    body += txt(CX + 28, y + 40, 'DULS.GYM · MEMBERSHIP', { size: 11, fill: C.mutedFg, ls: '0.08em' });
    body += txt(CX + 28, y + 72, 'millati izzatillah', { size: 20, weight: 600 });
    body += txt(CX + 28, y + 94, 'millatiizzatillah@gmail.com', { size: 12, fill: C.mutedFg });
    body += ico('activity', CX + lw - 52, y + 34, 28, C.primary);
    body += statusBadge(CX + 28, y + 118, 'active').svg;
    body += txt(CX + 28, y + 212, '10', { size: 58, weight: 700, fill: C.primary });
    body += txt(CX + 28 + tw('10', 58, 700) + 12, y + 212, 'kunjungan tersisa', { size: 14, fill: C.mutedFg });
    body += txt(CX + 28, y + 244, '0 kunjungan sudah digunakan · Tanpa batas masa aktif', { size: 13, fill: C.mutedFg });
    body += button(CX + 28, y + 288, 224, 44, 'Perpanjang membership', { size: 13, trailing: 'arrow-up-right' });
    const rx = CX + lw + 24;
    body += cardBox(rx, y, rw, 400);
    body += ico('shield-check', rx + 28, y + 28, 28, C.primary);
    body += txt(rx + 28, y + 96, 'Cara kerja membership', { size: 15, weight: 600 });
    const steps = [
      ['Beli paket kunjungan yang sesuai dengan kebutuhanmu.'],
      ['Pembayaran online diverifikasi otomatis.', 'Pembayaran di gym diverifikasi admin.'],
      ['Admin mencatat check-in; satu kunjungan', 'menggunakan satu kuota.'],
      ['Perpanjangan menambah sisa kuota,', 'bukan menggantikannya.']
    ];
    let sy = y + 118;
    steps.forEach((step, i) => {
      body += txt(rx + 28, sy + 13, `${i + 1}.`, { size: 13, fill: C.mutedFg });
      body += para(rx + 44, sy, step, { size: 12.5, fill: C.mutedFg, lh: 19 });
      sy += step.length * 19 + 18;
    });
    return appFrame(h, { admin: false, active: 'Membership', name: 'millati izzatillah', role: 'Anggota', body });
  },

  /* 9 · DATA ANGGOTA */
  Members: () => {
    const h = 918;
    let y = 116;
    let body = heading(y, { eyebrow: 'COMMUNITY / MEMBERS', title: 'Data anggota', desc: 'Kelola anggota gym dan bantu mereka mencapai tujuan.' });
    body += button(W - PAD - 152, y + 10, 152, 34, 'Undang anggota', { icon: 'plus', size: 12 });
    y += 103;
    body += rect(CX, y, 320, 40, { fill: 'none', stroke: C.border, rx: 8 });
    body += ico('search', CX + 14, y + 12, 16, C.mutedFg);
    body += txt(CX + 38, y + 25, 'Cari nama atau email anggota...', { size: 13, fill: C.mutedFg });
    body += rect(CX + 336, y, 152, 40, { fill: C.card, stroke: C.border, rx: 8 });
    body += txt(CX + 352, y + 25, 'Semua status', { size: 12 });
    y += 60;
    const t = tableBlock(CX, y, CW, {
      cols: [
        { label: 'Anggota', width: 420 },
        { label: 'Status', width: 200 },
        { label: 'Sisa kuota', width: 180 },
        { label: 'Kunjungan', width: 160 },
        { label: 'Tindakan', width: 168, align: 'right' }
      ],
      rows: MEMBERS.map((m) => [
        { t: 'member', name: m.name, email: m.email },
        { t: 'status', v: m.status },
        { v: String(m.remaining), sub: 'kali', weight: 600 },
        { v: `${m.visits} kali`, color: C.mutedFg },
        { t: 'actions', items: [{ name: 'pencil' }, { name: 'power' }, { name: 'trash-2', color: C.destructive }] }
      ])
    });
    body += t.svg;
    return appFrame(h, { admin: true, active: 'Data anggota', name: 'Nirwan', role: 'Administrator', body });
  },

  /* 10 · KELOLA PEMBAYARAN */
  Payments: () => {
    const h = 918;
    let y = 116;
    let body = heading(y, { eyebrow: 'FINANCE / PAYMENTS', title: 'Kelola pembayaran', desc: 'Periksa transaksi, verifikasi pembayaran, dan aktifkan kuota membership.' });
    y += 103;
    body += rect(CX, y, 288, 40, { fill: 'none', stroke: C.border, rx: 8 });
    body += ico('search', CX + 14, y + 12, 16, C.mutedFg);
    body += txt(CX + 38, y + 25, 'Cari nama anggota...', { size: 13, fill: C.mutedFg });
    body += rect(CX + 304, y, 176, 40, { fill: C.card, stroke: C.border, rx: 8 });
    body += txt(CX + 320, y + 25, 'Semua status', { size: 12 });
    body += rect(CX + 496, y, 160, 40, { fill: C.card, stroke: C.border, rx: 8 });
    body += txt(CX + 512, y + 25, 'Semua metode', { size: 12 });
    y += 60;
    const t = tableBlock(CX, y, CW, {
      cols: [
        { label: 'Transaksi', width: 280 },
        { label: 'Paket', width: 240 },
        { label: 'Nominal', width: 180 },
        { label: 'Metode', width: 150 },
        { label: 'Status', width: 180 },
        { label: '', width: 98, align: 'right' }
      ],
      rows: PAYS.map((p) => [
        { v: p.name, sub: p.date },
        { v: p.pkg, sub: `${p.visits} kunjungan` },
        { v: money(p.amount), weight: 500 },
        { v: p.method === 'gym' ? 'Di gym' : 'Online', color: C.mutedFg },
        { t: 'status', v: p.status },
        { t: 'link', v: p.status === 'pending' ? 'Verifikasi' : 'Detail' }
      ])
    });
    body += t.svg;
    return appFrame(h, { admin: true, active: 'Pembayaran', name: 'Nirwan', role: 'Administrator', body });
  },

  /* 11 · RIWAYAT PEMBAYARAN (anggota) */
  PaymentHistory: () => {
    const h = 918;
    let y = 116;
    let body = heading(y, { eyebrow: 'MY TRANSACTIONS', title: 'Riwayat pembayaran', desc: 'Semua transaksi dan status pembayaran membership dalam satu tempat.' });
    y += 103;
    body += rect(CX, y, 176, 40, { fill: C.card, stroke: C.border, rx: 8 });
    body += txt(CX + 16, y + 25, 'Semua status', { size: 12 });
    body += rect(CX + 192, y, 168, 40, { fill: C.card, stroke: C.border, rx: 8 });
    body += txt(CX + 208, y + 25, 'Semua metode', { size: 12 });
    y += 60;
    const rows = PAYS.filter((p) => p.name === 'millati izzatillah').concat(PAYS.slice(1, 5));
    const t = tableBlock(CX, y, CW, {
      cols: [
        { label: 'Transaksi', width: 280 },
        { label: 'Paket', width: 280 },
        { label: 'Nominal', width: 200 },
        { label: 'Metode', width: 168 },
        { label: 'Status', width: 200 }
      ],
      rows: rows.map((p) => [
        { v: p.date, sub: p.ref },
        { v: p.pkg, sub: `${p.visits} kunjungan` },
        { v: money(p.amount), weight: 500 },
        { v: p.method === 'gym' ? 'Di gym' : 'Online', color: C.mutedFg },
        { t: 'status', v: p.status }
      ])
    });
    body += t.svg;
    return appFrame(h, { admin: false, active: 'Riwayat pembayaran', name: 'millati izzatillah', role: 'Anggota', body });
  },

  /* 12 · LAPORAN */
  Reports: () => {
    const h = 1122;
    let y = 116;
    let body = heading(y, { eyebrow: 'INSIGHTS / REPORTS', title: 'Laporan gym', desc: 'Gambaran transaksi, pendapatan, dan aktivitas gym Anda.' });
    y += 103;
    body += field(CX, y, 176, { label: 'Dari tanggal', h: 38, placeholder: 'hh/bb/tttt' }).svg;
    body += field(CX + 192, y, 176, { label: 'Sampai tanggal', h: 38, placeholder: 'hh/bb/tttt' }).svg;
    body += txt(CX + 396, y + 44, 'Seluruh periode', { size: 12, fill: C.mutedFg });
    y += 76;
    body += statRow(y, [
      { label: 'Pembayaran lunas', value: '5', caption: 'Transaksi terverifikasi', icon: 'wallet' },
      { label: 'Pendapatan transaksi', value: 'Rp1.700.000', caption: 'Menurut tanggal pesanan', icon: 'activity' },
      { label: 'Menunggu verifikasi', value: '1', caption: 'Rp150.000', icon: 'clock-3' },
      { label: 'Total kunjungan', value: '8', caption: 'Check-in dalam periode ini', icon: 'users' }
    ]);
    y += 152;
    body += chartCard(CX, y, CW, 300, {
      title: 'Pendapatan membership', sub: 'Pembayaran terverifikasi per bulan',
      yTicks: ['2jt', '1,3jt', '666rb', '0'], max: 2000000,
      bars: [{ label: '2026-08', v: 600000 }, { label: '2026-09', v: 950000 }, { label: '2026-10', v: 1700000 }]
    });
    y += 324;
    const t = tableBlock(CX, y, CW, {
      cols: [
        { label: 'Paket', width: 400 },
        { label: 'Terjual', width: 220 },
        { label: 'Kuota terjual', width: 240 },
        { label: 'Pendapatan', width: 268 }
      ],
      rows: [
        [{ v: 'Starter', weight: 600 }, { v: '1' }, { v: '5 kunjungan', color: C.mutedFg }, { v: 'Rp150.000', color: C.primary }],
        [{ v: 'Momentum', weight: 600 }, { v: '1' }, { v: '15 kunjungan', color: C.mutedFg }, { v: 'Rp350.000', color: C.primary }],
        [{ v: 'Performance', weight: 600 }, { v: '3' }, { v: '90 kunjungan', color: C.mutedFg }, { v: 'Rp1.800.000', color: C.primary }]
      ]
    });
    body += t.svg;
    return appFrame(h, { admin: true, active: 'Laporan', name: 'Nirwan', role: 'Administrator', body });
  }
};

/* ────────────────────────── DESIGN SYSTEM ────────────────────────── */
function designSystem() {
  const h = 1240;
  let s = rect(0, 0, W, h, { fill: C.bg });
  s += txt(80, 90, 'Design system DulsGYM', { size: 34, weight: 700 });
  s += txt(80, 120, 'Token warna, tipografi, dan komponen yang dipakai di seluruh layar.', { size: 14, fill: C.mutedFg });

  // warna
  let y = 180;
  s += txt(80, y, 'WARNA', { size: 11, weight: 600, fill: C.primary, ls: '0.2em' });
  const swatches = [
    ['background', C.bg], ['card', C.card], ['secondary', C.secondary], ['muted', C.muted],
    ['border', C.border], ['foreground', C.fg], ['muted-foreground', C.mutedFg],
    ['primary', C.primary], ['accent', C.accent], ['destructive', C.destructive]
  ];
  swatches.forEach(([name, hex], i) => {
    const x = 80 + i * 132;
    s += rect(x, y + 24, 116, 84, { fill: hex, rx: 10, stroke: C.border });
    s += txt(x, y + 128, name, { size: 11, weight: 500 });
    s += txt(x, y + 144, hex, { size: 11, fill: C.mutedFg });
  });

  // tipografi
  y = 372;
  s += txt(80, y, 'TIPOGRAFI · Inter', { size: 11, weight: 600, fill: C.primary, ls: '0.2em' });
  const type = [
    ['Heading 1 · 30/700', 30, 700], ['Heading 2 · 20/700', 20, 700], ['Subjudul · 15/600', 15, 600],
    ['Body · 14/400', 14, 400], ['Small · 12/400', 12, 400], ['Caption · 11/400', 11, 400]
  ];
  type.forEach(([label, size, weight], i) => {
    const ty = y + 46 + i * 52;
    s += txt(80, ty, label, { size, weight });
    s += txt(560, ty, 'Pasang target, kejar progres, ulangi.', { size, weight, fill: C.mutedFg });
  });
  s += txt(80, y + 46 + 6 * 52, 'EYEBROW · 10/600 · TRACKING 0.2EM', { size: 10, weight: 600, fill: C.primary, ls: '0.2em' });

  // komponen
  y = 840;
  s += txt(80, y, 'KOMPONEN', { size: 11, weight: 600, fill: C.primary, ls: '0.2em' });
  s += button(80, y + 24, 160, 40, 'Tombol utama', { size: 13 });
  s += button(256, y + 24, 160, 40, 'Tombol outline', { size: 13, variant: 'outline' });
  s += button(432, y + 24, 140, 40, 'Ghost', { size: 13, variant: 'ghost' });
  s += button(588, y + 24, 132, 34, 'Ukuran kecil', { size: 12, icon: 'plus' });
  s += button(736, y + 24, 168, 40, 'Dengan ikon', { size: 13, icon: 'plus', trailing: 'arrow-up-right' });
  s += rect(80, y + 84, 240, 44, { fill: 'none', stroke: C.border, rx: 8 });
  s += txt(94, y + 111, 'Placeholder input', { size: 14, fill: C.mutedFg });
  s += rect(336, y + 84, 240, 44, { fill: 'none', stroke: C.primary, rx: 8 });
  s += txt(350, y + 111, 'Input fokus', { size: 14 });
  let bx = 592;
  ['active', 'pending', 'rejected', 'inactive'].forEach((v) => {
    const b = statusBadge(bx, y + 94, v);
    s += b.svg;
    bx += b.w + 12;
  });
  s += rect(80, y + 152, 200, 44, { fill: C.primary, rx: 8 });
  s += ico('layout-dashboard', 94, y + 165, 18, C.primaryFg, 2.2);
  s += txt(124, y + 179, 'Nav aktif', { size: 14, weight: 600, fill: C.primaryFg });
  s += txt(320, y + 179, 'Nav non-aktif', { size: 14, fill: C.mutedFg });
  s += cardBox(80, y + 216, 260, 128);
  s += txt(100, y + 256, 'Judul kartu', { size: 12, fill: C.mutedFg });
  s += txt(100, y + 302, 'Rp1.700.000', { size: 24, weight: 600 });
  s += txt(100, y + 322, 'Keterangan pendukung', { size: 11, fill: C.mutedFg });

  // radius & spasi
  y = 1160;
  s += txt(420, y - 20, 'RADIUS & SPASI', { size: 11, weight: 600, fill: C.primary, ls: '0.2em' });
  [['8', 8], ['12', 12], ['16', 16], ['24', 24]].forEach(([label, r], i) => {
    const x = 420 + i * 110;
    s += rect(x, y, 80, 48, { fill: C.secondary, rx: r });
    s += txt(x, y + 70, `radius ${label}px`, { size: 11, fill: C.mutedFg });
  });
  s += txt(900, y + 4, 'Spasi dasar: 4 · 8 · 12 · 16 · 20 · 24 · 28 · 36 · 44 px', { size: 12, fill: C.mutedFg });
  s += txt(900, y + 26, 'Lebar sidebar 240px · header 80px · padding konten 36px', { size: 12, fill: C.mutedFg });
  return s;
}

/* ────────────────────────── BOARD ────────────────────────── */
const ORDER = [
  ['Dashboard', '/', 'Admin'],
  ['Login', '/login', 'Publik'],
  ['Register', '/register', 'Publik'],
  ['ForgotPassword', '/forgot-password', 'Publik'],
  ['ResetPassword', '/reset-password', 'Publik'],
  ['Packages', '/paket', 'Admin & anggota'],
  ['PackageDetail', '/paket/:id', 'Anggota'],
  ['Membership', '/membership', 'Anggota'],
  ['Members', '/admin/anggota', 'Admin'],
  ['Payments', '/admin/pembayaran', 'Admin'],
  ['PaymentHistory', '/riwayat', 'Anggota'],
  ['Reports', '/admin/laporan', 'Admin']
];

const HEIGHTS = {
  Dashboard: 1319, ForgotPassword: 918, Login: 918, Register: 918, ResetPassword: 918,
  Packages: 1336, PackageDetail: 900, Membership: 918, Members: 918, Payments: 918,
  PaymentHistory: 918, Reports: 1122
};

const COLS = 3, GAPX = 160, GAPY = 150, MARGIN = 140, LABEL = 64;
const ROW_H = [1319, 1336, 918, 1122];
const boardW = MARGIN * 2 + COLS * W + (COLS - 1) * GAPX;

let board = '';
let cy = 300;
for (let r = 0; r < Math.ceil(ORDER.length / COLS); r++) {
  for (let c = 0; c < COLS; c++) {
    const item = ORDER[r * COLS + c];
    if (!item) continue;
    const [id, route, role] = item;
    const x = MARGIN + c * (W + GAPX);
    const fh = HEIGHTS[id];
    board += txt(x, cy, id, { size: 22, weight: 700 });
    board += txt(x, cy + 22, `${route}  ·  ${role}`, { size: 13, fill: C.mutedFg });
    board += `<g transform="translate(${x},${cy + LABEL})">${SCREENS[id]()}</g>`;
    board += rect(x, cy + LABEL, W, fh, { stroke: C.border, rx: 0 });
  }
  cy += ROW_H[r] + LABEL + GAPY;
}

// header board
let head = rect(0, 0, boardW, 260, { fill: C.canvas });
head += txt(MARGIN, 110, 'DulsGYM · UI/UX untuk Figma', { size: 40, weight: 700 });
head += txt(MARGIN, 146, '12 layar aplikasi + design system. Setiap layar adalah frame 1440px dengan layer terpisah.', { size: 15, fill: C.mutedFg });
head += txt(MARGIN, 176, 'Sumber: halaman aplikasi produksi (React + Tailwind) — struktur, warna, dan teks mengikuti implementasi sebenarnya.', { size: 13, fill: C.mutedFg });
head += txt(MARGIN, 206, 'Impor: Figma → File → Place image, atau drag & drop berkas SVG ini. Gunakan "Ungroup" untuk mengedit per komponen.', { size: 13, fill: C.primary });

const boardH = cy;
const dsY = boardH + 40;
board += `<g transform="translate(${MARGIN},${dsY})"><g transform="translate(0,0)">${designSystem()}</g></g>`;
const totalH = dsY + 1240 + 120;

const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${boardW}" height="${totalH}" viewBox="0 0 ${boardW} ${totalH}">
<defs>${defs.join('')}</defs>
<rect width="${boardW}" height="${totalH}" fill="${C.canvas}"/>
${head}
${board}
</svg>`;

const tokens = {
  $description: 'Token desain DulsGYM — selaras dengan src/index.css dan tailwind.config.js',
  color: Object.fromEntries(Object.entries({
    background: C.bg, card: C.card, foreground: C.fg, 'primary': C.primary,
    'primary-foreground': C.primaryFg, secondary: C.secondary, muted: C.muted,
    'muted-foreground': C.mutedFg, border: C.border, accent: C.accent, destructive: C.destructive
  }).map(([k, v]) => [k, { $type: 'color', $value: v }])),
  typography: {
    fontFamily: { $type: 'fontFamily', $value: 'Inter' },
    h1: { $type: 'typography', $value: { fontFamily: 'Inter', fontWeight: 700, fontSize: '30px', letterSpacing: '-0.01em' } },
    h2: { $type: 'typography', $value: { fontFamily: 'Inter', fontWeight: 700, fontSize: '20px' } },
    body: { $type: 'typography', $value: { fontFamily: 'Inter', fontWeight: 400, fontSize: '14px' } },
    small: { $type: 'typography', $value: { fontFamily: 'Inter', fontWeight: 400, fontSize: '12px' } },
    caption: { $type: 'typography', $value: { fontFamily: 'Inter', fontWeight: 400, fontSize: '11px' } },
    eyebrow: { $type: 'typography', $value: { fontFamily: 'Inter', fontWeight: 600, fontSize: '10px', letterSpacing: '0.2em' } }
  },
  radius: { sm: { $type: 'dimension', $value: '8px' }, md: { $type: 'dimension', $value: '12px' }, lg: { $type: 'dimension', $value: '16px' } },
  spacing: { 1: { $type: 'dimension', $value: '4px' }, 2: { $type: 'dimension', $value: '8px' }, 3: { $type: 'dimension', $value: '12px' }, 4: { $type: 'dimension', $value: '16px' }, 5: { $type: 'dimension', $value: '20px' }, 6: { $type: 'dimension', $value: '24px' }, 7: { $type: 'dimension', $value: '28px' }, 9: { $type: 'dimension', $value: '36px' } },
  layout: { sidebar: { $type: 'dimension', $value: '240px' }, header: { $type: 'dimension', $value: '80px' }, frame: { $type: 'dimension', $value: `${W}px` } }
};

const outDir = path.resolve('src/assets/figma');
fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(path.join(outDir, 'dulsgym-ui-kit.svg'), svg, 'utf8');
fs.writeFileSync(path.join(outDir, 'dulsgym-tokens.json'), JSON.stringify(tokens, null, 2), 'utf8');
console.log(`SVG  ${(svg.length / 1024).toFixed(0)} KB · ${ORDER.length} layar + design system · ${boardW}x${totalH}`);
console.log('Token JSON ditulis.');