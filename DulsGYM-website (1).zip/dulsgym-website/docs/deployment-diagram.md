# Deployment Diagram — DulsGYM (Sistem Manajemen Keanggotaan Gym)

Dokumen ini menggambarkan **arsitektur deployment** aplikasi DulsGYM: perangkat pengguna, hosting frontend,
runtime backend serverless, basis data, serta layanan pihak ketiga (Stripe dan email platform) yang benar-benar
dipakai oleh sistem ini.

- **URL produksi:** `https://dulsgym.base44.app`
- **Mode pembayaran saat ini:** Stripe **mode uji** (kartu uji `4242 4242 4242 4242`)
- **Stack frontend:** React 18 + Vite, Tailwind CSS, React Router, TanStack Query, Recharts
- **Backend:** fungsi serverless (Deno) + basis data entitas dengan Row-Level Security (RLS)

---

## 1. Diagram Deployment

```mermaid
flowchart TB
  subgraph U["1. Perangkat Pengguna"]
    BR["Browser desktop<br/>Chrome / Safari / Edge"]
    MB["Aplikasi mobile<br/>iOS &amp; Android — build dari kode yang sama"]
  end

  subgraph E["2. Edge &amp; Hosting — Base44"]
    CDN["CDN + static hosting<br/>HTTPS dulsgym.base44.app"]
    SPA["SPA bundle hasil build Vite<br/>beranda, login/daftar, dashboard admin,<br/>dashboard anggota, laporan"]
  end

  subgraph P["3. Platform Base44 — Backend-as-a-Service"]
    AUTH["Layanan identitas<br/>email + sandi, Google OAuth,<br/>OTP verifikasi, reset sandi"]
    GW["API gateway SDK<br/>HTTPS / JSON"]
    FN["Runtime fungsi serverless (Deno)<br/>gymAction · stripeCheckout<br/>verifyStripe · stripeWebhook"]
    SH["Modul bersama<br/>shared/gym.ts · shared/stripe.ts"]
    DB[("Basis data entitas + RLS<br/>GymMember · GymPackage<br/>GymPayment · GymVisit · User")]
    SEC["Brankas secret<br/>STRIPE_SECRET_KEY<br/>STRIPE_PUBLISHABLE_KEY<br/>STRIPE_WEBHOOK_SECRET"]
    MAIL["Layanan email platform<br/>undangan anggota, verifikasi akun,<br/>reset kata sandi"]
  end

  subgraph S["4. Stripe Cloud — mode uji"]
    CO["Stripe Checkout<br/>halaman pembayaran ter-hosting<br/>mata uang IDR"]
    PI["PaymentIntent<br/>kartu / metode bayar"]
    WH["Webhook endpoint Stripe"]
  end

  BR -->|HTTPS| CDN
  MB -->|HTTPS| CDN
  CDN --> SPA
  SPA -->|SDK auth: login, daftar, OTP, reset| AUTH
  SPA -->|SDK: baca/tulis entitas sesuai RLS| GW
  SPA -->|SDK invoke: gymAction| FN
  SPA -->|SDK invoke: verifyStripe| FN
  SPA -->|SDK invoke: stripeCheckout| FN
  SPA -->|redirect tab baru / halaman checkout| CO
  GW --> DB
  FN --> SH
  FN -->|asServiceRole: baca/tulis penuh| DB
  FN -->|baca kredensial saat runtime| SEC
  FN -->|Stripe API v1 / checkout.sessions| CO
  CO --> PI
  PI -->|event checkout.session.completed,<br/>async_payment_succeeded, expired| WH
  WH -->|POST + verifikasi tanda tangan<br/>/functions/stripeWebhook| FN
  AUTH --> MAIL
  DB -.->|aturan RLS: admin melihat semua data;<br/>anggota hanya data dengan email sendiri| GW
```

Versi teks (untuk dokumen cetak):

```text
[Browser / Aplikasi mobile]
        | HTTPS
        v
[CDN + static hosting  dulsgym.base44.app] --> [SPA React + Vite]
        |                                    |
        |                                    +--> [Layanan identitas Base44] --> [Email platform]
        |                                    |
        |                                    +--> [API gateway SDK] --> [(Basis data entitas + RLS)]
        |
        +--> [Runtime fungsi serverless]
                |  gymAction        -> [(Basis data)]
                |  stripeCheckout   -> [Stripe Checkout]
                |  verifyStripe     -> [Stripe Checkout]
                |  stripeWebhook <-  [Webhook Stripe] (signature verified)
                +-> [Brankas secret: STRIPE_*]
```

---

## 2. Node Deployment

| # | Node | Teknologi | Peran | Catatan deployment |
|---|------|-----------|-------|--------------------|
| 1 | Perangkat pengguna | Browser & aplikasi mobile | Menjalankan antarmuka SPA | Satu basis kode untuk web, iOS, dan Android |
| 2 | CDN + hosting statis | Hosting Base44 | Menyajikan aset hasil build (`dist/`) | Domain `dulsgym.base44.app` (dapat diganti domain kustom) |
| 3 | SPA | React 18, Vite, Tailwind, React Router, TanStack Query, Recharts | Seluruh halaman: beranda/dashboard, paket, membership, riwayat pembayaran, anggota, verifikasi pembayaran, laporan | Semua data diambil melalui SDK; tidak ada server frontend sendiri |
| 4 | Layanan identitas | Autentikasi Base44 | Login email+sandi, Google OAuth, OTP, reset sandi, undangan anggota | Peran akun (`admin` / `user`) menentukan tampilan dashboard |
| 5 | API gateway SDK | Base44 SDK | Baca/tulis entitas langsung dari klien, dibatasi RLS | Anggota hanya dapat membaca barisnya sendiri |
| 6 | Runtime fungsi serverless | Deno (`base44/functions/*/entry.ts`) | `gymAction`, `stripeCheckout`, `verifyStripe`, `stripeWebhook` | Stateless, dipanggil via HTTPS; log tersedia di halaman Logs |
| 7 | Modul bersama | `base44/shared/gym.ts`, `base44/shared/stripe.ts` | Aturan bisnis pembayaran & keanggotaan yang dipakai ulang antar-fungsi | Satu sumber logika, bukan salinan per fungsi |
| 8 | Basis data entitas | Penyimpanan Base44 + RLS | `GymMember`, `GymPackage`, `GymPayment`, `GymVisit`, `User` | Kuota kunjungan & status keanggotaan bersifat otoritatif di sini |
| 9 | Brankas secret | Secrets Base44 | Menyimpan tiga kredensial Stripe | Nilai hanya dibaca di sisi server, tidak pernah dikirim ke klien |
| 10 | Layanan email platform | Email Base44 | Verifikasi akun, undangan anggota, reset kata sandi | Tidak ada SMTP khusus aplikasi |
| 11 | Stripe Checkout | Stripe (mode uji) | Halaman pembayaran kartu, mata uang IDR | Return URL: `/riwayat?session_id={CHECKOUT_SESSION_ID}` |
| 12 | Webhook Stripe | Stripe webhooks | Memberi tahu hasil pembayaran ke sistem | Endpoint: `https://dulsgym.base44.app/functions/stripeWebhook` |

---

## 3. Koneksi, Port, dan Protokol

| Dari | Ke | Protokol / cara | Keterangan |
|------|----|-----------------|------------|
| Perangkat pengguna | CDN | HTTPS (443) | Aset statis & SPA |
| SPA | Layanan identitas | HTTPS via SDK | Login, daftar, OTP, reset sandi |
| SPA | API gateway entitas | HTTPS via SDK | Semua query & mutasi, difilter RLS |
| SPA | Fungsi serverless | HTTPS, `base44.functions.invoke` | `gymAction`, `stripeCheckout`, `verifyStripe` |
| SPA | Stripe Checkout | Redirect ke halaman Stripe | Dibuka sebagai halaman tingkat atas (bukan iframe) |
| Fungsi serverless | Basis data | Service role | Operasi istimewa: verifikasi pembayaran, check-in, undangan |
| Fungsi serverless | Secrets | Runtime API | Membaca kunci Stripe & `STRIPE_WEBHOOK_SECRET` |
| Fungsi serverless | Stripe API | HTTPS ke `api.stripe.com/v1` | Membuat sesi checkout, membaca status sesi |
| Stripe | `stripeWebhook` | HTTPS POST + tanda tangan | Diverifikasi dengan `STRIPE_WEBHOOK_SECRET`; event dengan `base44_app_id` berbeda diabaikan |
| Layanan identitas | Email platform | Internal platform | Email verifikasi, undangan, reset |

---

## 4. Alur Verifikasi Pembayaran (dampak deployment)

Ada dua jalur yang mengubah status pembayaran menjadi **lunas**, dan keduanya berjalan di sisi server:

1. **Webhook (otoritatif):** Stripe mengirim event ke `stripeWebhook` → tanda tangan diverifikasi →
   `confirmStripe` memeriksa `payment_id`, `currency = idr`, dan `amount_total` sama dengan nilai pesanan →
   kuota kunjungan anggota ditambah. Event `checkout.session.expired` menandai pembayaran kedaluwarsa.
2. **Kembali dari checkout:** SPA memanggil `verifyStripe` dengan `session_id` → sesi dibaca langsung dari Stripe →
   aturan kecocokan yang sama diterapkan. Hanya pemilik pembayaran (atau admin) yang boleh memicunya.

Pembayaran **di gym** (tunai) tidak menyentuh Stripe: admin mencatat pembayaran, lalu menyetujui atau menolaknya
melalui `gymAction` (`approve` / `reject`); persetujuan memakai aturan penambahan kuota yang sama.

---

## 5. Konfigurasi per Lingkungan

| Lingkungan | Host | Fungsi | Stripe |
|------------|------|--------|--------|
| Pratinjau (sandbox builder) | `preview-sandbox--…` | Sama, dipakai untuk pengujian | Mode uji |
| Produksi (publik) | `https://dulsgym.base44.app` | Sama, dipakai pengguna nyata | Mode uji → dapat ditingkatkan ke live |

**Secret yang wajib tersedia di runtime fungsi:** `STRIPE_SECRET_KEY`, `STRIPE_PUBLISHABLE_KEY`,
`STRIPE_WEBHOOK_SECRET`. Rotasi kunci Stripe atau penggantian endpoint webhook mengharuskan
`STRIPE_WEBHOOK_SECRET` diperbarui agar verifikasi tanda tangan tetap valid.

---

## 6. Catatan Operasional

- **Check-in:** setiap check-in mengurangi kuota dan mencatat baris `GymVisit`; bila pencatatan kunjungan gagal,
  kuota otomatis dikembalikan sehingga data tetap konsisten.
- **Idempotensi:** pembayaran menyimpan `applied_payments`, jadi satu transaksi hanya menambah kuota satu kali
  meskipun webhook dan halaman kembali sama-sama terpicu.
- **Pemantauan:** kegagalan fungsi tercatat pada halaman Logs; pengawasan khusus diperlukan untuk `stripeWebhook`
  karena kegagalan di sana berarti pembayaran tidak otomatis menambah kuota (masih dapat diverifikasi lewat admin).
- **Batas keamanan:** data anggota hanya dapat dibaca oleh anggota tersebut atau admin; penulisan data keanggotaan
  dan pembayaran dilakukan lewat fungsi serverless, bukan langsung dari klien.