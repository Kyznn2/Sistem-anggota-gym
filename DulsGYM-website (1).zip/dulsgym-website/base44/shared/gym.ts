export async function ensureMember(client, user) {
  const page = await client.entities.GymMember.filter({email:user.email}, {limit:1});
  let member = page.items[0];
  if (member?.deleted) throw new Error('Akun anggota dinonaktifkan. Hubungi admin gym.');
  if (!member) member = await client.entities.GymMember.create({email:user.email,user_id:user.id,name:user.full_name || user.email.split('@')[0],phone:'',remaining:0,total_visits:0,applied_payments:[],status:'inactive',deleted:false});
  else if (!member.user_id) member = await client.entities.GymMember.update(member.id,{user_id:user.id});
  return member;
}
export async function newPayment(client, member, packageId, method) {
  const pack = await client.entities.GymPackage.get(packageId);
  if (!pack || !pack.active || pack.price < 10000 || !Number.isInteger(pack.visits) || pack.visits < 1) throw new Error('Paket tidak tersedia.');
  if (!member || member.deleted) throw new Error('Anggota tidak tersedia.');
  return await client.entities.GymPayment.create({member_id:member.id,user_id:member.user_id || '',email:member.email,member_name:member.name,package_id:pack.id,package_name:pack.name,amount:pack.price,visits:pack.visits,method,status:'pending'});
}
export async function settlePayment(client, id) {
  let payment = await client.entities.GymPayment.get(id);
  if (!payment || !['pending','paid'].includes(payment.status)) throw new Error('Pembayaran tidak dapat dikonfirmasi.');
  if (payment.status !== 'paid') payment = await client.entities.GymPayment.update(id,{status:'paid',paid_at:new Date().toISOString()});
  const member = await client.entities.GymMember.get(payment.member_id);
  if (!member || member.deleted) throw new Error('Anggota tidak tersedia.');
  await client.entities.GymMember.updateMany({id:member.id,applied_payments:{$nin:[id]}},{$inc:{remaining:payment.visits},$addToSet:{applied_payments:id},$set:{status:member.status === 'suspended' ? 'suspended' : 'active'}});
  return payment;
}