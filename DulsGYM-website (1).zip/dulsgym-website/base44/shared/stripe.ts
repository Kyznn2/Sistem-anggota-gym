import Stripe from 'npm:stripe@17.7.0';
import { secrets } from 'base44:runtime';
import { settlePayment } from './gym.ts';
export function stripeClient() {return new Stripe(secrets.get('STRIPE_SECRET_KEY'));}
export async function confirmStripe(db, session) {
 const id = session.metadata?.payment_id;
 if (!id || session.metadata?.base44_app_id !== secrets.get('BASE44_APP_ID')) throw new Error('Metadata pembayaran tidak valid.');
 const p = await db.entities.GymPayment.get(id);
 if (!p || p.method !== 'online' || (p.session_id && p.session_id !== session.id) || session.currency !== 'idr' || session.amount_total !== Math.round(p.amount * 100)) throw new Error('Pembayaran tidak sesuai pesanan.');
 if (!p.session_id) await db.entities.GymPayment.update(p.id,{session_id:session.id});
 if (session.payment_status !== 'paid') return {status:p.status};
 return await settlePayment(db,p.id);
}