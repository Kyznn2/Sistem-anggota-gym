import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { secrets } from 'base44:runtime';
import { stripeClient, confirmStripe } from '../../shared/stripe.ts';
export default async function(req) {
 try {
  const base = createClientFromRequest(req);
  await base.auth.isAuthenticated();
  const signature = req.headers.get('stripe-signature');
  if (!signature) return Response.json({error:'Signature required'},{status:400});
  const event = await stripeClient().webhooks.constructEventAsync(await req.text(),signature,secrets.get('STRIPE_WEBHOOK_SECRET'));
  const s = event.data.object;
  if (s.metadata?.base44_app_id !== secrets.get('BASE44_APP_ID')) return Response.json({received:true});
  if (['checkout.session.completed','checkout.session.async_payment_succeeded'].includes(event.type)) await confirmStripe(base.asServiceRole,s);
  if (event.type === 'checkout.session.expired') await base.asServiceRole.entities.GymPayment.updateMany({id:s.metadata.payment_id,status:'pending'},{$set:{status:'expired'}});
  return Response.json({received:true});
 } catch(error) {console.error('stripeWebhook:',error.message); return Response.json({error:error.message},{status:400});}
}