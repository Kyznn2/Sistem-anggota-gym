import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { ensureMember, newPayment, settlePayment } from '../../shared/gym.ts';
export default async function(req) {
 try {
  const base = createClientFromRequest(req), user = await base.auth.me();
  if (!user) return Response.json({error:'Silakan masuk.'},{status:401});
  const body = await req.json(), {action,id} = body;
  const db = base.asServiceRole;
  if (action === 'ensureMember') return Response.json(await ensureMember(db,user));
  if (action === 'requestCash') {
   const member = await ensureMember(db,user);
   return Response.json(await newPayment(db,member,body.package_id,'gym'));
  }
  if (user.role !== 'admin') return Response.json({error:'Hanya admin yang dapat melakukan tindakan ini.'},{status:403});
  if (action === 'invite') {
   const email = String(body.email || '').trim().toLowerCase();
   if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) throw new Error('Email tidak valid.');
   await base.users.inviteUser(email,'user');
   const old = await db.entities.GymMember.filter({email},{limit:1});
   if (!old.items.length) await db.entities.GymMember.create({email,name:String(body.name || email.split('@')[0]).slice(0,100),phone:'',status:'inactive',remaining:0,total_visits:0,applied_payments:[],deleted:false});
   return Response.json({ok:true});
  }
  if (action === 'cashForMember') return Response.json(await newPayment(db,await db.entities.GymMember.get(body.member_id),body.package_id,'gym'));
  if (action === 'approve' || action === 'reject') {
   const p = await db.entities.GymPayment.get(id);
   if (!p || p.method !== 'gym' || p.status !== 'pending') throw new Error('Hanya pembayaran di gym yang menunggu dapat diverifikasi.');
   if (action === 'approve') return Response.json(await settlePayment(db,id));
   return Response.json(await db.entities.GymPayment.update(id,{status:'rejected',note:String(body.note || 'Pembayaran tidak diterima').slice(0,500)}));
  }
  if (!['editMember','deleteMember','toggleMember','checkin'].includes(action)) return Response.json({error:'Tindakan tidak dikenal.'},{status:400});
  const member = await db.entities.GymMember.get(id);
  if (!member || member.deleted) throw new Error('Anggota tidak tersedia.');
  if (action === 'editMember') {
   const name = String(body.name || '').trim();
   if (!name || name.length > 100) throw new Error('Nama wajib diisi, maksimal 100 karakter.');
   return Response.json(await db.entities.GymMember.update(id,{name,phone:String(body.phone || '').slice(0,30)}));
  }
  if (action === 'deleteMember') {
   if(member.email === user.email) throw new Error('Anda tidak dapat menghapus akun Anda sendiri.');
   return Response.json(await db.entities.GymMember.update(id,{deleted:true,status:'suspended'}));
  }
  if (action === 'toggleMember') {
   if (member.status !== 'suspended' && member.status !== 'inactive') return Response.json(await db.entities.GymMember.update(id,{status:'suspended'}));
   if (member.remaining < 1) throw new Error('Verifikasi pembelian paket terlebih dahulu untuk menambah kuota.');
   return Response.json(await db.entities.GymMember.update(id,{status:'active'}));
  }
  if (action === 'checkin') {
   if (member.status !== 'active' || member.remaining < 1) throw new Error('Membership tidak aktif atau kuota habis.');
   const result = await db.entities.GymMember.updateMany({id,remaining:member.remaining,status:'active'},{$inc:{remaining:-1,total_visits:1},$set:{status:member.remaining === 1 ? 'inactive' : 'active'}});
   if (result.updated !== 1) throw new Error('Data berubah, muat ulang dan coba kembali.');
   const after = await db.entities.GymMember.get(id);
   try {
    const visit = await db.entities.GymVisit.create({member_id:id,email:member.email,member_name:member.name,checkin_at:new Date().toISOString()});
    return Response.json({member:after,visit});
   } catch (error) {
    await db.entities.GymMember.updateMany({id},{$inc:{remaining:1,total_visits:-1}});
    await db.entities.GymMember.updateMany({id,status:'inactive',remaining:{$gt:0}},{$set:{status:'active'}});
    throw error;
   }
  }
  return Response.json({error:'Tindakan tidak dikenal.'},{status:400});
 } catch(error) {console.error('gymAction:',error.message); return Response.json({error:error.message},{status:400});}
}