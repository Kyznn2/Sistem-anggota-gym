import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { secrets } from 'base44:runtime';
import { stripeClient } from '../../shared/stripe.ts';
import { newPayment } from '../../shared/gym.ts';
export default async function(req) {
 try {
  const base = createClientFromRequest(req);
  if (!await base.auth.isAuthenticated()) return Response.json({error:'Silakan masuk untuk membeli paket.'},{status:401});
  const {package_id,member_id,origin} = await req.json();
  const target = new URL(origin);
  if (target.protocol !== 'https:' || !(/\.(base44\.app|base44\.com)$/.test(target.hostname))) throw new Error('Alamat kembali tidak valid.');
  const member = await base.entities.GymMember.get(member_id);
  if (!member || member.deleted) throw new Error('Anggota tidak tersedia.');
  const p = await newPayment(base.asServiceRole,member,package_id,'online');
  const stripe = stripeClient();
  const session = await stripe.checkout.sessions.create({mode:'payment',payment_method_types:['card'],customer_email:member.email,line_items:[{price_data:{currency:'idr',unit_amount:Math.round(p.amount * 100),product_data:{name:p.package_name,description:`${p.visits} kunjungan gym`}},quantity:1}],success_url:`${target.origin}/riwayat?session_id={CHECKOUT_SESSION_ID}`,cancel_url:`${target.origin}/riwayat?cancelled=1`,metadata:{base44_app_id:secrets.get('BASE44_APP_ID'),payment_id:p.id},payment_intent_data:{metadata:{base44_app_id:secrets.get('BASE44_APP_ID'),payment_id:p.id}}},{idempotencyKey:p.id});
  await base.asServiceRole.entities.GymPayment.update(p.id,{session_id:session.id});
  return Response.json({url:session.url,payment_id:p.id,session_id:session.id});
 } catch(error) {console.error('stripeCheckout:',error.message); return Response.json({error:error.message},{status:400});}
}