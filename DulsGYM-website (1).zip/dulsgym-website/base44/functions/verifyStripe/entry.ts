import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import { stripeClient, confirmStripe } from '../../shared/stripe.ts';
export default async function(req) {
 try {
  const base = createClientFromRequest(req),user = await base.auth.me();
  if (!user) return Response.json({error:'Silakan masuk.'},{status:401});
  const {session_id} = await req.json();
  if (!/^cs_(test_|live_)?[a-zA-Z0-9]{10,200}$/.test(session_id || '')) throw new Error('Sesi tidak valid.');
  const session = await stripeClient().checkout.sessions.retrieve(session_id);
  const p = await base.entities.GymPayment.get(session.metadata?.payment_id);
  if (!p || (p.email !== user.email && user.role !== 'admin')) return Response.json({error:'Tidak diizinkan.'},{status:403});
  return Response.json(await confirmStripe(base.asServiceRole,session));
 } catch(error) {console.error('verifyStripe:',error.message); return Response.json({error:error.message},{status:400});}
}